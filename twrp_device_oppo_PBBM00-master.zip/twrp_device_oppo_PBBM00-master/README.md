# twrp_device_oppo_OP4AED

Twrp Device Tree For oppo A7x

    * touch not work
